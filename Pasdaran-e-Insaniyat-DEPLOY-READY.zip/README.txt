Pasdaran-e-Insaniyat deploy-ready website.
Main file is already named index.html.
Upload index.html to GitHub Pages repository root.
